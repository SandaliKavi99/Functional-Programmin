object Q1 extends App{
     
     val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
     val Encryption = (character:Char, key:Int, alph:String) => alph((alph.indexOf(character.toUpper)+key)%alph.size)
     val Decryption = (character:Char, key:Int, alph:String) => alph((alph.indexOf(character.toUpper)-key)%alph.size)


     val cipher = (algo:(Char,Int,String)=> Char, str:String, key:Int, alp:String)=>str.map(algo(_,key,alp))

     val encrypt = cipher(Encryption,"s",5,alphabet)
     println(encrypt);
     val  decrypt = cipher(Decryption,encrypt,5,alphabet)
     println(decrypt)

  
}