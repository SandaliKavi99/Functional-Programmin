object Q4 extends App{


    def CheckNumber(num:Int):Any= num match{
        case x if x<0 => println("Negative number is given!")
        case x if x==0 => println("Zero is given!")
        case x if (x>0 & x%2==0) => println("Even Number is given!")
        case x if (x>0 & x%2!=0) => println("Odd number is given!")
    }
   
   print("Enter a Number : ")
   val number = scala.io.StdIn.readInt()
   CheckNumber(number)

   



    


    

}   