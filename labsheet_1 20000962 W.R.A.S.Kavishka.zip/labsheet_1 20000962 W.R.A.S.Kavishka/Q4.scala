object Q4 {

  def attendees(tPrice:Int):Int = 120 + (15-tPrice)/5*20;

  def revenue(tPrice:Int):Int = attendees(tPrice) * tPrice;

  def cost(tPrice:Int):Int = 500+ 3* attendees(tPrice);

  def profit(tPrice:Int):Int = revenue(tPrice) - cost(tPrice);

  def main(args:Array[String])={

     // Assumptions : ticket price can not be descreased less than 10 and increased more than 1000 
    var tprice:Int = 10;
    var bestTprice:Int=0;
    var maxProfit:Int =0;

    for(tprice <- 10 to 1000){
         if(profit(tprice)> maxProfit){
            maxProfit= profit(tprice);
            bestTprice=tprice;
         } 
    }

   printf("Best Ticket Price : %d",bestTprice);


  }
}