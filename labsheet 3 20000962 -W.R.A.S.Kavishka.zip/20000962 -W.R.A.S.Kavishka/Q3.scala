object Q3 {


    def volumeOfSphere(r:Double):Double= 4/3 * math.Pi *r *r *r;
    

    def main(args:Array[String])={

        
        println(volumeOfSphere(5));

    

 }
}