object Q1 {

 def main(args:Array[String])={

    var k:Int =2;
   var i:Int = 2;
   var j:Float = 2;
   var m:Float = 5;
   var n:Float = 5;
   var f:Float = 12.0f;
   var g:Float = 4.0f;
   var c= "X";

   println("%f",k+12*m);

   println("%f",m/j);

   println("%f",n % j);

   println("%f",m / j * j);

   println("%f",f + 10*5 +g);

   println("%f",(i+1)*n);

 }

}





