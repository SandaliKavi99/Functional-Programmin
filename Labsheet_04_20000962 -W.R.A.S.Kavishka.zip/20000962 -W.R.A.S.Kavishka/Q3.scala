object Q3 extends App{

   
   def toUpper(name:String):String= name.toUpperCase()

   def toLower(name:String):String= name.toLowerCase()

   def formatNames(name:String,caseMethod:Int,character:String, position:Int):String={

       /* caseMethod 
           1 for to UpperCase
           2 for to Lowercase */

      var newStr =""
      var char= ""
      for(i <- 0 to name.length()-1 ){
      
         if(i==position-1 & name(i).toString == character){
         
            if(caseMethod==1){
               char=toUpper(character)
            }
            else{
               char=toLower(character)
            }

            newStr = newStr+char
         }

         else{
             newStr = newStr+name(i)
         }
      
      }
      return newStr
   }


   println(toUpper("Benny"))

   println(formatNames("Nimal",1,"i",2))

   println(toLower("Saman"))
   
   println(formatNames("Kumara",1,"a",6))

             
            

}   