object Q2 {

 def main(args:Array[String])={

   var a:Int = 2;
   var b:Int = 3;
   var c:Int = 4;
   var d:Int = 5;
   var k:Float = 4.3f;

    println("%d", (b-1) * a + c *(d-1));
    println("%d",a+1);

    var value:Float=(-2) *( d - k )+c;
    println ("%.2f",value);

    c=c+1;
    println ("%d",c);

    c=(c+1)*(a+1);
    println ("%d",c);
 }
}