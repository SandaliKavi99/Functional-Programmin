object Q3 {

    def wage(hours:Int):Double = hours *250;

    def ot(hours:Int):Double = hours *85;

    def income(h1:Int,h2:Int):Double = wage(h1)+ot(h2);

    def tax(income:Double):Double = income * 0.12;

    def takeHomeSalary(h1:Int,h2:Int):Double = income(h1,h2)-tax(income(h1,h2));

  def main(args:Array[String])={
            


          printf("TakeHome salary : %.2f",takeHomeSalary(40,30));


  }
}


