object Q2 {

   def Fahrenheit(C:Float):Double= C * 1.8 + 32;
    

   def main(args:Array[String])={

        println(Fahrenheit(35));

    }
}