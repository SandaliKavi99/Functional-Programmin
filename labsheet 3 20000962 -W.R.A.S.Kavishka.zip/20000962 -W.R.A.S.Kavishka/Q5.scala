object Q5 {


    def easySpace(n:Float):Float=n*8;
    def Tempo(m:Float):Float=m*7;
    

    def main(args:Array[String])={

        var TotalRunningTime:Float = easySpace(2)+Tempo(3)+easySpace(2);
        println(TotalRunningTime);
    }
}