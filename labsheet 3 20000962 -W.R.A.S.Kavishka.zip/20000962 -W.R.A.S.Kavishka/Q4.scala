object Q4 {

    def TotalBookPrice(n:Int):Double= 24.95 * n;
    def discountForCover(amount:Double):Double= amount * 0.4;
    def shippingCost(m:Int):Double= if(m<=50) m*3 else 50*3+(m-50)*0.75;
    
    def TotalCostForBooks(k:Int):Double= TotalBookPrice(k)-discountForCover(TotalBookPrice(k))+shippingCost(k);

    def main(args:Array[String])={

        
        println(TotalCostForBooks(60));
    }
}